<?php

// Label
function vh_gap($atts, $content = null, $code) {
	extract( shortcode_atts( array(
		'height' => 10,
	), $atts ) );

	$output = '<div class="gap" style="line-height: ' . absint($height) . 'px; height: ' . absint($height) . 'px;"></div>';

	return $output;
}
add_shortcode('vh_gap', 'vh_gap');

// News post slider
function vh_post_slider( $atts, $content = null ) {
	extract( shortcode_atts( array(
				'post_slider_category'   => '',
				'post_slider_auto'       => '',
				'post_slider_speed'      => '',
				'post_slider_limit'      => '',
				'post_slider_link'       => '',
				'post_slider_animation'  => ''
			), $atts ) );

	$random = rand();
	$output = $post_slider_auto_output = '';

	if ( $post_slider_auto == 'true' ) {
		$post_slider_auto_output = 'interval: 2000,
						 target: "+=1",
						 autostart: true';
	} elseif ( $post_slider_auto == 'false' ) {
		$post_slider_auto_output = 'autostart: false';
	} else {
		$post_slider_auto_output = 'autostart: true,
						 target: "+=1",
						 interval: ' . $post_slider_auto;
	}

	if ($post_slider_speed == null ) {
		$post_slider_speed = ' 2000';
	} else {
		$post_slider_speed =  $post_slider_speed;
	}

	// $output .= '
	// <script type="text/javascript">
	// 	jQuery(document).ajaxStop(function($) {
	// 			[].slice.call( document.querySelectorAll( ".dotstyle.number_' . $random . ' > ul" ) ).forEach( function( nav ) {
	// 				new DotNav( nav, {
	// 					callback : function( idx ) {
	// 					}
	// 				});
	// 			});
	// 		jQuery(".imageSliderExt.number_' . $random . ' ul li").eq(0).addClass("current");

	// 		';

	// 		if ( $post_slider_auto != 'false' ) {
	// 			$output .= '
	// 				jQuery(".post_carousel_content.number_' . $random . ', .imageSliderExt.number_' . $random . '").hover(function() {
	// 					jQuery(".post_carousel_content.number_' . $random . '").jcarouselAutoscroll("stop");
	// 				}, function() {
	// 					jQuery(".post_carousel_content.number_' . $random . '").jcarouselAutoscroll("start");
	// 				});';
	// 		}

	// 		$output .= '
	// 		jQuery(".imageSliderExt.number_' . $random . ' ul").on("jcarouselpagination:active", "li", function() {
	// 			jQuery(this).addClass("current");
	// 		}).on("jcarouselpagination:inactive", "li", function() {
	// 			jQuery(this).removeClass("current");
	// 		}).jcarouselPagination({
	// 			perPage: 1,';
			
	// 		$output .= '
	// 			"item": function(page, carouselItems) {
	// 				return \'<li><a href="#\' + page + \'"></a></li>\';
	// 			}
	// 		});

	// 		jQuery(".imageSliderExt.number_' . $random . ' ul").append("<li><!-- dummy dot --></li>");

	// 		jQuery(window).bind("debouncedresize", function() {
	// 			jQuery(".imageSliderExt.number_' . $random . ' ul").append("<li><!-- dummy dot --></li>");
	// 			jQuery(".dotstyle.number_' . $random . ' li").removeClass("current");
	// 			jQuery(".dotstyle.number_' . $random . ' li:first-child").addClass("current");
	// 		});

	// 		jQuery(".post_slider_main_prev").click(function(e) {
	// 			e.preventDefault();
	// 			carousel_' . $random . '.jcarousel("scroll", "-=1");
	// 		});

	// 		jQuery(".post_slider_main_next").click(function(e) {
	// 			e.preventDefault();
	// 			carousel_' . $random . '.jcarousel("scroll", "+=1");
	// 		});
			
	// 	});
	// </script>';

	$output .= '<div class="post_slider_controls">
				<div class="post_slider_right_controls">';
				if ( $post_slider_link != '' || $post_slider_link != null ) {
					$output .= '<a href="' . $post_slider_link . '" class="post_slider_main_link">+</a>';
				}
					
		$output .= '<div class="post_slider_buttons"><a href="#" class="post_slider_main_prev"></a><a href="#" class="post_slider_main_next"></a></div>
					<div class="imageSliderExt dotstyle number_' . $random . ' dotstyle-dotmove"><ul></ul></div>
				</div>
				<div class="post_slider_nav">
				<a href="#" class="post_slider_recent active">'.__('Recent news', 'vh').'</a>
				<a href="#" class="post_slider_popular">'.__('Popular news', 'vh').'</a>
				<div class="clearfix"></div>
				</div>
				</div>
				<div class="clearfix"></div>';
	$output .= '<div id="post_carousel_content" class="post_carousel_content number_' . $random . '"></div>';
	$output .= '<input type="hidden" id="post_slider_categories" value="' . $post_slider_category . '">
				<input type="hidden" id="post_slider_limit" value="' . $post_slider_limit . '">
				<input type="hidden" id="post_slider_random" value="' . $random . '">
				<input type="hidden" id="post_slider_auto" value="' . $post_slider_auto . '">
				<input type="hidden" id="post_slider_speed" value="' . $post_slider_speed . '">';

	return $output;
}
add_shortcode('vh_post_slider', 'vh_post_slider');

// event post slider
function vh_event_slider( $atts, $content = null ) {
		extract( shortcode_atts( array(
				'event_slider_title'   => '',
				'event_slider_auto'       => '',
				'event_slider_speed'      => '',
				'event_slider_limit'      => '',
				'event_slider_link'       => '',
				'event_slider_animation'  => ''
			), $atts ) );

		global $wp_query, $tribe_ecp, $post;
		$event_slider_auto_output  = '';

		// Temporarily unset the tribe bar params so they don't apply
		$hold_tribe_bar_args = array();
		foreach ($_REQUEST as $key => $value) {
			if ($value && strpos($key, 'tribe-bar-') === 0) {
				$hold_tribe_bar_args[$key] = $value;
				unset($_REQUEST[$key]);
			}
		}

		if (!function_exists('tribe_get_events')) return;

		if ( $event_slider_auto == 'true' ) {
			$event_slider_auto_output = 'interval: 2000,
							 target: "+=1",
							 autostart: true';
		} elseif ( $event_slider_auto == 'false' ) {
			$event_slider_auto_output = 'autostart: false';
		} else {
			$event_slider_auto_output = 'autostart: true,
							 target: "+=1",
							 interval: ' . $event_slider_auto;
		}

		if ( $event_slider_speed == null ) {
			$event_slider_speed = ' 2000';
		} else {
			$event_slider_speed =  $event_slider_speed;
		}

		$posts = tribe_get_events(apply_filters('tribe_events_list_widget_query_args', array(
			'eventDisplay' => 'list',
			'posts_per_page' => $event_slider_limit
		)));

		// // If no posts, and the don't show if no posts checked, let's bail
		if (!$posts) return;

		$output = '';
		$count = 1;
		$random = rand();

		$output .= '
		<script type="text/javascript">
			jQuery(document).ready(function($) {
					[].slice.call( document.querySelectorAll( ".dotstyle.number_' . $random . ' > ul" ) ).forEach( function( nav ) {
						new DotNav( nav, {
							callback : function( idx ) {
							}
						});
					});
				jQuery(".imageSliderExt.number_' . $random . ' ul li").eq(0).addClass("current");

				var carousel_' . $random . ' = jQuery(".event_carousel_content.number_' . $random . '").on("jcarousel:animate", function(event, carousel) {
						jQuery(".post_slider_image").addClass("active");
					}).on("jcarousel:animateend", function(event, carousel) {
						jQuery(".post_slider_image").removeClass("active");
					}).jcarousel({
					wrap: "circular",
					animation: {
						easing: "' . $event_slider_animation . '",
						duration: ' . $event_slider_speed . '
					}
				}).jcarouselAutoscroll({
					' . $event_slider_auto_output . '
				});';

				if ( $event_slider_auto != 'false' ) {
					$output .= '
						jQuery(".event_carousel_content.number_' . $random . ', .imageSliderExt.number_' . $random . '").hover(function() {
							jQuery(".event_carousel_content.number_' . $random . '").jcarouselAutoscroll("stop");
						}, function() {
							jQuery(".event_carousel_content.number_' . $random . '").jcarouselAutoscroll("start");
						});';
				}

				$output .= '
				jQuery(".imageSliderExt.number_' . $random . ' ul").on("jcarouselpagination:active", "li", function() {
					jQuery(this).addClass("current");
				}).on("jcarouselpagination:inactive", "li", function() {
					jQuery(this).removeClass("current");
				}).jcarouselPagination({
					carousel: carousel_' . $random . ',
					perPage: 1,';
				
				$output .= '
					"item": function(page, carouselItems) {
						return \'<li><a href="#\' + page + \'"></a></li>\';
					}
				});

				jQuery(".imageSliderExt.number_' . $random . ' ul").append("<li><!-- dummy dot --></li>");

				jQuery(window).bind("debouncedresize", function() {
					jQuery(".imageSliderExt.number_' . $random . ' ul").append("<li><!-- dummy dot --></li>");
					jQuery(".dotstyle.number_' . $random . ' li").removeClass("current");
					jQuery(".dotstyle.number_' . $random . ' li:first-child").addClass("current");
				});

				jQuery(".event_slider_main_prev").click(function(e) {
					e.preventDefault();
					carousel_' . $random . '.jcarousel("scroll", "-=1");
				});

				jQuery(".event_slider_main_next").click(function(e) {
					e.preventDefault();
					carousel_' . $random . '.jcarousel("scroll", "+=1");
				});
				
			});
		</script>';

		$output .= '<h1 class="event_slider_title">' . $event_slider_title . '</h1>';

		$output .= '<div class="event_slider_controls">
				<div class="event_slider_right_controls">';
				if ( $event_slider_link != '' || $event_slider_link != null ) {
					$output .= '<a href="' . $event_slider_link . '" class="event_slider_main_link">+</a>';
				}
					
		$output .= '<div class="event_slider_buttons"><a href="#" class="event_slider_main_prev"></a><a href="#" class="event_slider_main_next"></a></div>
					<div class="imageSliderExt dotstyle number_' . $random . ' dotstyle-dotmove"><ul></ul></div>
				</div>
				</div>
				<div class="clearfix"></div>';

		$output .= '<div id="event_carousel_content" class="event_carousel_content number_' . $random . '">
					<ul>';

		foreach ( $posts as $event ) {
			if ( $count % 2 ) {
				$li_class = 'odd';
			} else {
				$li_class = 'even';
			}

			$time_format = get_option( 'time_format', Tribe__Events__Date_Utils::TIMEFORMAT );
			$time_range_separator = tribe_get_option('timeRangeSeparator', ' - ');

			$start_time = tribe_get_start_date( $event, false, $time_format );
			$end_time = tribe_get_end_date( $event, false,  $time_format );

			$date_format = get_option('date_format', 'j M');

			$output .= '<li class="' . $li_class . '"><div class="event_slider_main_container">
			<div class="event_slider_info">';
			$output .= '
				<div class="event_slider_date icon-calendar">' . date_i18n($date_format, strtotime($event->EventStartDate)) . '</div>
				<div class="time icon-clock-1">' . $start_time . ' '.$time_range_separator.' ' . $end_time . '</div>';
			$output .= '</div>
			<div class="clearfix"></div>
			<div class="event_slider_content">
				<div class="event_slider_event_title"><a href="' . $event->guid . '">' . $event->post_title . '</a></div>';
				if ( strlen(strip_tags($event->post_content)) > 150 ) {
					$event_content = substr(strip_tags($event->post_content), 0, 150) . '..';
				} else {
					$event_content = strip_tags($event->post_content);
				}
				$output .= '<div class="event_slider_event_content">' . $event_content . '</div>
			</div>
			</div></li>';

			$count++;
		}
		$output .= '</ul>
		</div>';

		return $output;
}
add_shortcode('vh_event_slider', 'vh_event_slider');

// Animals and places
function vh_animals_places( $atts, $content = null ) {
	extract( shortcode_atts( array(
				'animals_places_title'   => '',
				'animals_places_link'    => '',
				'animals_places_animals' => '',
				'animals_places_places'  => '',
				'animals_places_limit'   => ''
			), $atts ) );

	$output = '';

	$output .= "<div id='animal_main_container'></div>
	<input type=\"hidden\" id=\"animal_places_animals\" value=\"".$animals_places_animals."\">
	<input type=\"hidden\" id=\"animal_places_places\" value=\"".$animals_places_places."\">
	<input type=\"hidden\" id=\"animal_places_limit\" value=\"".$animals_places_limit."\">
	<input type=\"hidden\" id=\"animal_places_link\" value=\"".$animals_places_link."\">";

	return $output;
}
add_shortcode('vh_animals_places', 'vh_animals_places');

// Newsletter
function vh_newsletter( $atts, $content = null ) {
	extract( shortcode_atts( array(
			'newsletter_title'           => '',
			'newsletter_introduction'    => ''
		), $atts ) );

	global $newsletter;

	if (!class_exists('NewsletterSubscription')) {
		return '';
	}

	// $buffer = apply_filters('widget_text', $newsletter_introduction, $instance);
	$options = get_option('newsletter');
	$options_profile = get_option('newsletter_profile');

	if (stripos($newsletter_introduction, '<form') === false) {

		$form = NewsletterSubscription::instance()->get_form_javascript();

		$form .= '<div class="newsletter">';
		$form .= '<h1>' . $newsletter_title . '</h1>';
		$form .= '<span class="newsletter_start">' . str_replace('/', '</span><span>', $newsletter_introduction) . '</span>';
		$form .= NewsletterWidget::get_widget_form();
		$form .= '</div>';

		$buffer = "";

		// Canot user directly the replace, since the form is different on the widget...
		if (strpos($buffer, '{subscription_form}') !== false)
			$buffer = str_replace('{subscription_form}', $form, $buffer);
		else {
			if (strpos($buffer, '{subscription_form_') !== false) {
				// TODO: Optimize with a method to replace only the custom forms
				$buffer = $newsletter->replace($buffer);
			} else {
				$buffer .= $form;
			}
		}
	} else {
		$buffer = str_ireplace('<form', '<form method="post" action="' . plugins_url('newsletter/do/subscribe.php') . '" onsubmit="return newsletter_check(this)"', $buffer);
		$buffer = str_ireplace('</form>', '<input type="hidden" name="nr" value="widget"/></form>', $buffer);
	}

	// That replace all the remaining tags
	$buffer = $newsletter->replace($buffer);

	return $buffer;

}
add_shortcode('vh_newsletter', 'vh_newsletter');


// Team members
function vh_team_member( $atts, $content = null ) {
	extract( shortcode_atts( array(
			'team_member_name'           => '',
			'team_member_description'    => '',
			'team_member_picture'        => '',
			'team_member_facebook'       => '',
			'team_member_twitter'        => '',
			'team_member_youtube'        => '',
			'team_member_form'           => '',
			'team_member_title'          => ''
		), $atts ) );

	$output = '';

	$picture = wp_get_attachment_image_src($team_member_picture);

	$output .= '
	<div class="contact-form-member">
		<div class="member-photo">
			<img src="' . $picture[0] . '"/>
			<div class="member-social">
				<a href="' . $team_member_facebook . '" class="member-facebook icon-facebook-squared"></a>
				<a href="' . $team_member_twitter . '" class="member-twitter icon-twitter-squared"></a>
				<a href="' . $team_member_youtube . '" class="member-youtube icon-youtube-squared"></a>
				<div class="clearfix"></div>
			</div>
		</div>
		<div class="member-name">
			' . $team_member_name . '
		</div>
		<div class="member-description">
			' . $team_member_description . '
		</div>
		<div class="member-send">
			<a href="about:blank" class="wpb_button wpb_btn-transparent wpb_regularsize contacts-member-send">' . __('Send email', 'vh') . '</a>
			<input type="hidden" class="contact-form-id" value="' . $team_member_form . '">
		</div>
	</div>';

	return $output;

}
add_shortcode('vh_team_member', 'vh_team_member');

function vh_contact_form( $atts, $content = null ) {
	extract( shortcode_atts( array(
			'contact_form_ids'           => ''
		), $atts ) );

	$output = '';

	$ids = explode(',', $contact_form_ids);

	$output .= '
	<div class="contact-form-send">';
		
		foreach ($ids as $value) {
			$output .= '<div class="contact-form-container-' . $value . '">
			<h3>' . __('Send e-mail to ', 'vh') . '</h3>';
			$output .= do_shortcode( '[contact-form-7 id="' . $value . '"]' );
			$output .= '</div>';
		}
		
	$output .= '</div>';

	
	return $output;

}
add_shortcode('vh_contact_form', 'vh_contact_form');

// Twitter
function vh_twitter( $atts, $content = null ) {
	extract( shortcode_atts( array(
			'twitter_username'  => '',
			'twitter_limit'     => '',
			'twitter_link'      => ''
		), $atts ) );

	wp_enqueue_script('jquery.tweet', get_stylesheet_directory_uri() . '/js/jquery.tweet.js', array('jquery'), '', TRUE);
	wp_localize_script( 'jquery.tweet', 'twitter_ajax', array( 'twitterurl' => plugins_url( 'environmental-plugin/lib/widgets/twitter/index.php' ) ) );

	$random = rand();

	$output = '';

	if ( get_option('vh_twitter_consumer_key') && get_option('vh_twitter_consumer_secret') && get_option('vh_twitter_user_token') && get_option('vh_twitter_user_secret') ) {
		$output .= '
		<script type="text/javascript">
			jQuery(function($) {
				jQuery("#twitter_container_'.$random.'").tweet({
					username: ["'.$twitter_username.'"],
					count: '.$twitter_limit.',
					avatar_size: 0,
					seconds_ago_text: "'. __("about %d seconds ago", "vh") .'",
					a_minutes_ago_text: "'. __("about a minute ago", "vh") .'",
					minutes_ago_text: "'. __("about %d minutes ago", "vh") .'",
					a_hours_ago_text: "'. __("about an hour ago", "vh") .'",
					hours_ago_text: "'. __("about %d hours ago", "vh") .'",
					a_day_ago_text: "'. __("about a day ago", "vh") .'",
					days_ago_text: "'. __("about %d days ago", "vh") .'",
					loading_text: "loading.."
				});
			});
		</script>';
	}

	$output .= '
	<div id="twitter_container_'.$random.'" class="twitter_container"></div>
	<div class="twitter-controls">
		<div class="twitter-buttons">
			<a href="#" class="twitter-prev"></a>
			<a href="#" class="twitter-next"></a>
		</div>
		<div class="twitter-link">
			<a href="'.$twitter_link.'">+</a>
		</div>
	</div>
	';

	return $output;

}
add_shortcode('vh_twitter', 'vh_twitter');

// Animals and places table
function vh_animals_places_table( $content = null ) {

	global $post;
	$output = '';

	$output .= '<div class="open-animals-info-container">';
		if ( get_post_meta( $post->ID, 'animal_location', true ) != null || get_post_meta( $post->ID, 'animal_location', true ) != '' ) {
			$output .= '<div class="animals-info-item">
				<span class="icon-info">' . __( 'Location:', 'vh' ) . '</span>
				<div class="animals-info-text">' . get_post_meta( $post->ID, 'animal_location', true ) . '</div>
			</div>';
		}
		if ( get_post_meta( $post->ID, 'animal_name', true ) != null || get_post_meta( $post->ID, 'animal_name', true ) != '' ) {
			$output .= '<div class="animals-info-item">
				<span class="icon-info">' . __( 'Specific name:', 'vh' ) . '</span>
				<div class="animals-info-text">' . get_post_meta( $post->ID, 'animal_name', true ) . '</div>
			</div>';
		}
		if ( get_post_meta( $post->ID, 'animal_habitat', true ) != null || get_post_meta( $post->ID, 'animal_habitat', true ) != '' ) {
			$output .= '<div class="animals-info-item">
				<span class="icon-info">' . __( 'Habitat:', 'vh' ) . '</span>
				<div class="animals-info-text">' . get_post_meta( $post->ID, 'animal_habitat', true ) . '</div>
			</div>';
		}
		if ( get_post_meta( $post->ID, 'animal_height', true ) != null || get_post_meta( $post->ID, 'animal_height', true ) != '' ) {
			$output .= '<div class="animals-info-item">
				<span class="icon-info">' . __( 'Height:', 'vh' ) . '</span>
				<div class="animals-info-text">' . get_post_meta( $post->ID, 'animal_height', true ) . '</div>
			</div>';
		}
		if ( get_post_meta( $post->ID, 'animal_weight', true ) != null || get_post_meta( $post->ID, 'animal_weight', true ) != '' ) {
			$output .= '<div class="animals-info-item">
				<span class="icon-info">' . __( 'Weight:', 'vh' ) . '</span>
				<div class="animals-info-text">' . get_post_meta( $post->ID, 'animal_weight', true ) . '</div>
			</div>';
		}
		if ( get_post_meta( $post->ID, 'animal_population', true ) != null || get_post_meta( $post->ID, 'animal_population', true ) != '' ) {
			$output .= '<div class="animals-info-item">
				<span class="icon-info">' . __( 'Population:', 'vh' ) . '</span>
				<div class="animals-info-text">' . get_post_meta( $post->ID, 'animal_population', true ) . '</div>
			</div>';
		}
		$output .= '<div class="clearfix"></div></div>';

	return $output;
}
add_shortcode('vh_animals_places_table', 'vh_animals_places_table');

// Animals and places list
function vh_animals_places_list( $atts, $content = null ) {
	extract( shortcode_atts( array(
			'animals_places_list_category'  => '',
			'animals_places_list_limit'     => '',
			'animals_places_list_type'      => ''
		), $atts ) );

	global $post;
	$output = '';
	
	$args = array(
	'numberposts' => -1,
	'post_type' => 'animals_places',
	'vh_categories' => $animals_places_list_category,
	'posts_per_page' => $animals_places_list_limit,
	'orderby' => 'date'
	);

	$the_query = new WP_Query( $args );

	if( $the_query->have_posts() ) {
		$output .= '<ul class="animals-places-list">';
		while ( $the_query->have_posts() ) {
			$the_query->the_post();

			$population_color = ' style="background-color: #6ab9a3"';
			if ( get_post_meta( get_the_id(), 'animal_color', true ) == 'env_red' ) {
				$color = '#ff4747';
				$population_color = ' style="background-color: ' . $color . '"';
			} elseif ( get_post_meta( get_the_id(), 'animal_color', true ) == 'env_orange' ) {
				$color = '#ffa319';
				$population_color = ' style="background-color: ' . $color . '"';
			} elseif ( get_post_meta( get_the_id(), 'animal_color', true ) == 'env_green' ) {
				$color = '#6ab9a3';
				$population_color = ' style="background-color: ' . $color . '"';
			} elseif ( get_post_meta( get_the_id(), 'animal_color', true ) != '' ) {
				$color = get_post_meta( get_the_id(), 'animal_color', true );
				$population_color = ' style="background-color: ' . $color . '"';
			}

			$output .= '
			<li class="animals_places">
				<div class="animals-places-main-container">
					<div class="animals-places-image">
						<a href="' . get_permalink( $post->ID ) . '">' . get_the_post_thumbnail( $post->ID, 'donation-project' ) . '</a>
						<div class="animals-img-overlay"><a href="' . get_permalink( $post->ID ) . '">' . __('Read article', 'vh') . '</a></div>';
				$output .= '
					</div>';
				if ( $animals_places_list_type != 'Places' ) {
					$output .= '
					<div class="animals-places-population"' . $population_color . '>
						<span class="population-main">' . __('Population:', 'vh') . '</span>
						<span class="population-text">' . get_post_meta( get_the_id(), 'animal_population', true ) . '</span>
					</div>';
				} else {
					$output .= '
					<div class="animals-places-population"' . $population_color . '>
						<span class="population-main">' . __('Status:', 'vh') . '</span>
						<span class="population-text">' . get_post_meta( get_the_id(), 'animal_population', true ) . '</span>
					</div>';
				}
				$output .= '
					<div class="animals-places-title">
						<a href="' . get_permalink( $post->ID ) . '">' . get_the_title() . '</a>
					</div>';
					if ( get_post_meta( get_the_id(), 'animal_location', true ) != '' ) {
						$output .= '<span class="animals-places-location icon-location">' . get_post_meta( get_the_id(), 'animal_location', true ) . '</span>';
					}
					$output .= '
					<div class="animals-places-content">';
						$content = str_replace("[vc_row][vc_column][vc_column_text]","",get_the_content());
						if ( strlen(strip_tags($content)) > 150 ) {
							$project_content = '<p>' . substr(strip_tags($content), 0, 150) . '..</p>';
						} else {
							$project_content = '<p>' . strip_tags($content) . '</a>';
						}
						$output .= 
						$project_content . '
					</div>
				</div>';
			$output .= '
			</li>';
		}
		$output .= '</ul><div class="clearfix"></div>';
	}

	return $output;
}
add_shortcode('vh_animals_places_list', 'vh_animals_places_list');

function vh_vcgi_image( $atts ) {
	$output = '{{vh_post_image_module}}';
	return $output;
}
add_shortcode( 'vh_vcgi_image', 'vh_vcgi_image' );

function vh_vcgi_content( $atts ) {
	$output = '{{vh_post_content_module}}';
	return $output;
}
add_shortcode( 'vh_vcgi_content', 'vh_vcgi_content' );

function vh_vcgi_readmore( $atts ) {
	$output = '{{vh_post_readmore_module}}';
	return $output;
}
add_shortcode( 'vh_vcgi_readmore', 'vh_vcgi_readmore' );

function vh_vcgi_categories( $atts ) {
	$output = '{{vh_post_category_module}}';
	return $output;
}
add_shortcode( 'vh_vcgi_categories', 'vh_vcgi_categories' );